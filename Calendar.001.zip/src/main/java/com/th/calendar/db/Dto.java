package com.th.calendar.db;

public class Dto {
	public String b_no;         
	public String b_writeTime;      
	public String b_title;         
	public String b_text;   
	public String b_date;        
	public String b_ch;       
	public String b_year;
	public String b_month;
	public String b_day;
	
	public Dto(String b_no, String b_title, String b_text, String b_date, String b_ch) {
		super();
		this.b_no = b_no;
		this.b_title = b_title;
		this.b_text = b_text;
		this.b_date = b_date;
		this.b_ch = b_ch;
	}  
	
	public Dto(String b_no, String b_date, String b_title, String b_text, String b_ch, String b_writeTime) {
		super();
		this.b_no = b_no;
		this.b_date = b_date;
		this.b_title = b_title;
		this.b_text = b_text;
		this.b_ch = b_ch;
		this.b_writeTime = b_writeTime;
	}  
	
	
	public Dto(String b_date, String b_title,
			String b_text, String b_ch, String b_year,
			String b_month, String b_day) {
		super();
		this.b_title = b_date;
		this.b_text = b_title;
		this.b_date = b_text;
		this.b_ch = b_ch;
		this.b_year = b_year;
		this.b_month = b_month;
		this.b_day = b_day;
	}  
	
	
	
	
	
//	rs.getString("b_no"),
//	rs.getString("b_date"),
//	rs.getString("b_title"),
//	rs.getString("b_text"),
//	rs.getString("b_writeTime")
	
//	public Dto(String , String , String ) {
//		super();
//		this. = ;
//		this. = ;
//		this. = ;
//	}  
//	
}








