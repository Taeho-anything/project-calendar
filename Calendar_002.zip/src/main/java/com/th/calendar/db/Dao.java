package com.th.calendar.db;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.th.calendar.Schedule;
public class Dao extends Da {
	
//	캘린더 리스트
//	=====================================================================================================
	
	
	public ArrayList<Schedule> summmary(int month) {
		ArrayList<Schedule> prt = new ArrayList<>();
		connect();
		try {
		String sql = String.format("select*from %s where b_month=%s",Db.TABLE_board, month);
		ResultSet rs = st.executeQuery(sql);
		while(rs.next()){
			String hid_no = rs.getString("b_no");
			String hid_title = rs.getString("b_title");
			String hid_date = rs.getString("b_date");
			String hid_ch = rs.getString("b_ch");
			
			prt.add(new Schedule(hid_no, hid_title, hid_date, hid_ch));
			}
		
	}catch (Exception e) {
		e.printStackTrace();
	}
		close();
		return prt;
	}
	
//	==========================================================================================================
	
	
	public Dto read(String no) {
		Dto post = null;
		connect();
		try {
			String sql = String.format(
					"select * from %s where b_no=%s"
					,Db.TABLE_board, no);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Dto(
					rs.getString("b_no"),
					rs.getString("b_date"),
					rs.getString("b_title"),
					rs.getString("b_text"),
					rs.getString("b_ch"),
					rs.getString("b_writeTime")
					);
			
	}catch (Exception e) {
		e.printStackTrace();
	}
		close();
		return post;
	}
	
	
//	==========================================================================================================
	
	/* 삭제 */
	public void del(String no) {
		connect();
		try {
			String sql = String.format("delete from %s where b_no=%s"
					,Db.TABLE_board, no);
			
			st.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
	}
	
	
//	==========================================================================================================
	
	
	/* 쓰기 */
	public void write(Dto d) {
		connect();
		try {
			String sql = String.format("insert into board (b_title, b_text, b_date, b_ch, b_year, b_month, b_day, b_writeTime)"
					+"values ('"
					+d.b_title+"','"
					+d.b_text+"','"
					+d.b_date+"','"
					+d.b_ch+"','"
					+d.b_year+"','"
					+d.b_month+"','"
					+d.b_day+"', now())");
			
			st.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
	}
	
	
//	==========================================================================================================
	
	
	public void edit(Dto d) {
		connect();
		try {
			String sql = String.format("update board set "
			+"b_title='"+d.b_title+"', "
			+"b_text='"+d.b_text+"', "
			+"b_ch='"+d.b_ch+"', "
			+"b_writeTime = now() "
			+"where b_no = "+d.b_no);
			
		st.executeUpdate(sql);	
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
	}
	
	
//	==========================================================================================================
	
	public int getPageCount() {
		int count = 0;
		connect();
		try {
			String sql = String.format(
					"select count(*) from %s"
					,Db.TABLE_board);
			System.out.println("sql:"+sql);//todo
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();	//[고정4,5]
		return count;
	}
	
	
	
	
	
	
	
}